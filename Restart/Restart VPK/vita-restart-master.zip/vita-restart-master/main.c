int main()
{
	return scePowerRequestColdReset();
}