---
name: Feature request
about: Suggest an idea for this project

---

<!-- Describe your request here. Make sure nobody else suggested this idea already ! -->
