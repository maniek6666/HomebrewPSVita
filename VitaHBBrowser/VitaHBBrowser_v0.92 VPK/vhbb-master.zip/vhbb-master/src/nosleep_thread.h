#pragma once

#include <psp2/types.h>

void StartNoSleepThread();
int nosleep_thread(SceSize args, void *argp);
