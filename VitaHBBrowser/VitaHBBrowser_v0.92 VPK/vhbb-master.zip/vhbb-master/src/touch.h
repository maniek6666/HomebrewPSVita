#pragma once



#define TOUCH_HEIGHT 1087
#define TOUCH_WIDTH 1919