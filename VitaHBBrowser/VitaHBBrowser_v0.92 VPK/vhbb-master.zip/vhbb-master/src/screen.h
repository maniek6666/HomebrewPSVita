#pragma once

#define SCREEN_HEIGHT 544
#define SCREEN_WIDTH 960