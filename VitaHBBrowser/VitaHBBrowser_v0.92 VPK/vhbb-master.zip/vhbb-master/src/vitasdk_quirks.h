#pragma once

void terminate_logger();