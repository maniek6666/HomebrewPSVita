#include "View.h"

View::~View() = default;

int View::HandleInput(int focus, const Input& input) {return 0;}
int View::Display() {return 0;}
